<?php
date_default_timezone_set('Asia/Jakarta');

$key = "POG+8S9A6fHkYU2IU6+DNV8MqErd50s04Rsf0XpD2NVQB7zR7s6q9QMP/g87JYUn
CpZhFOvf4DQQDWwI7kWUWnM42OMLEwoKkCU70crgqk1IP741D7lElJt9O+ZCYMrb
0mfco0HpHkyJzowEX+wGejA54caJAX6mM21eTU2pUQJ/RUHhSaExNriX52rrghzX
liSBVw0TPzXGyzPHhJuAJ47bSDaVFJLXmXG1AioOpMdQak6ilVYa6wWC2ycUOXS3
6bk6nP3+tewf2cNb21oxHHFR+3ZzUC6ecGf40D1Sqfsy+CljemOQC0PWq3AV1wM5
G5BQz4TIO1LEIApo0Wg2Yw==";

$issued_at = time();
$expiration_time = $issued_at + (60 * 60);
$issuer = "RestApiAuthJWT";
