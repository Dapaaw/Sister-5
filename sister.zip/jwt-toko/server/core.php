<?php
date_default_timezone_set('Asia/Jakarta');

$key = "AmQKVH99KXQG8jeA9N2invI+2VbOvRm1LfNtbIjd3ZgSachJWRTUgVLZJ4qVjH0s
P7aKpIBbZj+FpQ/HQQJBANnRVddMtlihW/WtMyYjbaoZ9iv0YxI3XhrHLQ83bkQQ
cyu4pKFqwQpqz0IsCmkS4AR1h5ICfyd6LrhdaTJei4kCQQDRj2+WCbw9WLPjVJSA
qrlg3E8vkHzC8gQDwcZVaXrG/9KlDcTZANXbJz0boi3UQgg2jWW+lK9bkskGaqPU
6lCZAkEAzU0U1sB0Ymd8cLyWKE1eUOT1dYp8UrAjH6Q6IUyCvt6uXzhC2+3uE26G
+XzfNxhWU32fkYyO4tuz64wH2jTo2QJADPtx0j2wJ6zDGCY5PO9WpKWBUlUFJZ6Q
mRr8CnaKYKGgjxEXTMo8dWMs6fVWGXwtvhNsZi4X3vhs87TPiXUqoQJAHt26J76V
ZhTNkw3XAKiz122V9BpqEcK5ehyJluB/DzJ8cUgmFOEBZcb91KmMF1pI/KVpcKIs
jIeKWwhq4d8K4Q==
";

$issued_at = time();
$expiration_time = $issued_at + (60 * 60);
$issuer = "RestApiAuthJWT";
